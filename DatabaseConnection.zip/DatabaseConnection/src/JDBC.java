import java.sql.*;
public class JDBC {
    protected static final String CONNECT_DATABASE = "jdbc:mysql://localhost:3306/demo_bank";
    protected static final String USERNAME = "root";
    protected static final String PASSWORD = "toor";
    protected static final String SELECT_BANK = "SELECT trans_id,acct_no,old_bal,trans_type,trans_amt, new_bal, trans_stat FROM banktransactions";
    protected static final String SELECT_VALID = "SELECT trans_id,trans_type,trans_amt, validity FROM validtrans";
    protected static final String SELECT_INVALID = "SELECT trans_id,trans_type,trans_amt, validity FROM invalidtrans";
    protected static final String UPDATE_BANK = "update banktransactions Set new_bal = ? , trans_stat = ? WHERE trans_id=?";
    protected static final String INSERT_VALID = "insert into validtrans(trans_id,trans_type,trans_amt,validity) values (?,?,?,?)";
    protected static final String INSERT_INVALID = "insert into invalidtrans(trans_id,trans_type,trans_amt,validity) values (?,?,?,?)";

    protected static void getConnection() throws SQLException {

        Connection con  = DriverManager.getConnection(CONNECT_DATABASE,USERNAME,PASSWORD);
            System.out.println(con);
        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery(SELECT_BANK);

        System.out.println("The bank transactions table");

        while (rs.next()){
            processingTrans(con,rs);
        }

        System.out.println();
        System.out.println("The valid transactions table");

        showTablesValidTrans(con);

        System.out.println();
        System.out.println("The invalid transactions table");

        showTablesInValidTrans(con);

        con.close();


    }

    protected static void processingTrans(Connection con, ResultSet rs) throws SQLException{

        int mtrans_id = rs.getInt(1);
        String macct_no = rs.getString(2);
        double mold_bal = rs.getDouble(3);
        String mtrans_type = rs.getString(4);
        double mtrans_amt = rs.getDouble(5);
        double mnew_bal = rs.getDouble(6);
        String mtrans_stat = rs.getString(7);

        System.out.println(mtrans_id + "   " + macct_no + "   " + mold_bal + "   " + mtrans_type + "   " +
                mtrans_amt + "  " + mnew_bal + "  " + mtrans_stat );

        double new_balance = calculateNewBal(mold_bal,mtrans_amt,mtrans_type);
        String validity = "";
        String tableName = "";

        if(new_balance < 0){
            validity = "Invalid";
            tableName = "invalidtrans";
        }else
        {
            validity = "Valid";
            tableName = "validtrans";
        }

        insetIntoTable(con,tableName,mtrans_id,mtrans_type,mtrans_amt,validity);
        setUpdateBank(con,new_balance,validity,mtrans_id);
    }

    protected static double calculateNewBal(double moldBal, double mtransAmt, String mtransType) {
        if ( mtransType.equalsIgnoreCase("W")){
            return moldBal - mtransAmt;
        }else{
            return moldBal + mtransAmt;
        }
    }

    protected static void insetIntoTable(Connection con, String tableName, int mtrans_id, String mtrans_type, double mtrans_amt, String mtrans_stat) throws SQLException{

        String insertQuery = "";

        if(tableName.equalsIgnoreCase("validtrans")){
            insertQuery = INSERT_VALID;
        }else {
            insertQuery = INSERT_INVALID;
        }
        PreparedStatement stmti = con.prepareStatement(insertQuery);
        stmti.setDouble(1,mtrans_id);
        stmti.setString(2,mtrans_type);
        stmti.setDouble(3,mtrans_amt);
        stmti.setString(4,mtrans_stat);
        stmti.executeUpdate();
    }

    protected static void setUpdateBank(Connection con, double mnew_bal, String mtrans_stat, int mtrans_id) throws SQLException{
        PreparedStatement stmtu = con.prepareStatement(UPDATE_BANK);
        stmtu.setDouble(1,mnew_bal);
        stmtu.setString(2,mtrans_stat);
        stmtu.setInt(3,mtrans_id);
        stmtu.executeUpdate();
    }

    protected static void showTablesValidTrans(Connection con) throws SQLException{

        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery(SELECT_VALID);

        while (rs.next()){
            int mtrans_id = rs.getInt(1);
            String mtrans_type = rs.getString(2);
            double mtrans_amt = rs.getDouble(3);
            String mvalidity = rs.getString(4);
            System.out.println( mtrans_id + " " + mtrans_type + " " + mtrans_amt + " " + mvalidity);

        }
    }

    protected static void showTablesInValidTrans(Connection con) throws SQLException{

        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery(SELECT_INVALID);

        while (rs.next()){
            int mtrans_id = rs.getInt(1);
            String mtrans_type = rs.getString(2);
            double mtrans_amt = rs.getDouble(3);
            String mvalidity = rs.getString(4);
            System.out.println( mtrans_id + " " + mtrans_type + " " + mtrans_amt + " " + mvalidity);

        }
    }


}
